import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-tag',
  templateUrl: './update-tag.component.html',
  styleUrls: ['./update-tag.component.css']
})
export class UpdateTagComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
