import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-specialite',
  templateUrl: './update-specialite.component.html',
  styleUrls: ['./update-specialite.component.css']
})
export class UpdateSpecialiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
