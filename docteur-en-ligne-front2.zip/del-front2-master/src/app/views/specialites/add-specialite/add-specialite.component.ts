import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-specialite',
  templateUrl: './add-specialite.component.html',
  styleUrls: ['./add-specialite.component.css']
})
export class AddSpecialiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
